using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;


public class colorOnClick : NetworkBehaviour {
    Color[] colors = new Color[] {Color.white, Color.red, Color.green, Color.blue, Color.yellow};
    private int currentColor, length;
    [SyncVar] Renderer SphereRenderer;

	// Use this for initialization
	void Start () {
        GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
		currentColor = 0; //White
        length = colors.Length;
        SphereRenderer = sphere.GetComponent<Renderer>();
        SphereRenderer.material.SetColor("_Color", colors[currentColor]);
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		if(Input.GetMouseButtonDown(0)) {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, 10000))
            {
                currentColor = (currentColor+1)%length;
                Material temp = new Material(Shader.Find("Standard"));
                temp.SetColor("_Color", colors[currentColor]);
                hit.transform.gameObject.GetComponent<Renderer>().material = temp;
            }
        }
    }
}
